package query.parser.vo;

import java.util.ArrayList;
import java.util.List;

public class WhereInfo implements QueryComponentType{
	// �񱳿�����
	private String relationOp;
	
	// �� ���
	private List<QueryComponentType> valueList = new ArrayList<QueryComponentType>();

	public String getRelationOp() {
		return relationOp;
	}

	public void setRelationOp(String relationOp) {
		this.relationOp = relationOp;
	}

	public List<QueryComponentType> getValueList() {
		return valueList;
	}

	public void setValueList(List<QueryComponentType> valueList) {
		this.valueList = valueList;
	}
	
	public void addValueToList(QueryComponentType value){
		this.valueList.add(value);
	}
}
