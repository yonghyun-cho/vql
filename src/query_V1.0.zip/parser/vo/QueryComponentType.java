package query.parser.vo;

public interface QueryComponentType {
}
