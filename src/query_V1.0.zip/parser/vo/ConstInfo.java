package query.parser.vo;

public class ConstInfo implements PrimitiveType{
	
	private String constValue = "";
	private String typeName = "";
	
	public String getConstValue() {
		return constValue;
	}
	public void setConstValue(String constValue) {
		this.constValue = constValue;
	}
	public String getTypeName() {
		return typeName;
	}
	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}
	
}
