package query.parser.vo;

import java.util.ArrayList;
import java.util.List;

import query.parser.QueryCommVar;

public class ConditionInfo implements QueryComponentType {
	
	// �񱳿����� ��
	private String comparisionOp = "";

	// �� �� ���
	private List<QueryComponentType> valueList = new ArrayList<QueryComponentType>();

	public String getComparisionOp() {
		return comparisionOp;
	}

	public void setComparisionOp(String comparisionOp) {
		this.comparisionOp = comparisionOp;
	}

	public List<QueryComponentType> getValueList() {
		return valueList;
	}

	public void setValueList(List<QueryComponentType> valueList) {
		this.valueList = valueList;
	}
	
	public String toString(){
		String result = "<�񱳿����� : [" + this.comparisionOp + "] >\n";
		
		for(int i = 0; i < valueList.size(); i++){
			result = result + valueList.get(i) + "\n";
		}
		
		return result;
	}
	
	public static ConditionInfo convertStringToInfo(String value) throws Exception{
		ConditionInfo conditionInfo = new ConditionInfo();
		
		for(int j = 0; j < QueryCommVar.COMPARISION_OP_LIST.length; j++){
			if(value.indexOf(QueryCommVar.COMPARISION_OP_LIST[j]) > 0){
				String[] splitCondition = value.split(QueryCommVar.COMPARISION_OP_LIST[j]);
				
				conditionInfo.setComparisionOp(QueryCommVar.COMPARISION_OP_LIST[j]);
				
				List<QueryComponentType> valueList = new ArrayList<QueryComponentType>();
				for(int k = 0; k < splitCondition.length; k++){
					ColumnInfo columnInfo = ColumnInfo.convertStringToInfo(splitCondition[k]);
					valueList.add(columnInfo);
				}
				conditionInfo.setValueList(valueList);
				
				break;
			}
		}
		
		return conditionInfo;
	}
}
