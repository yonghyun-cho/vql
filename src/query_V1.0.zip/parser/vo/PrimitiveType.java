package query.parser.vo;

public interface PrimitiveType extends QueryComponentType{
}
