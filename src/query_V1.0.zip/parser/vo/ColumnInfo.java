package query.parser.vo;

public class ColumnInfo implements PrimitiveType{
	private String columnName;
	private String tableName;
	
	public String getColumnName() {
		return columnName;
	}
	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}
	public String getTableName() {
		return tableName;
	}
	public void setTableName(String tableName) {
		this.tableName = tableName;
	}
	
	public String toString(){
		return "TABLE�� : [" + this.tableName + "] // COLUMN�� : ["+ this.columnName + "]";
	}
	
	public static ColumnInfo convertStringToInfo(String value) throws Exception{
		String trimmedValue = value.trim();
		String [] splitSelectStmt = trimmedValue.split("\\.");
		ColumnInfo columnInfo = new ColumnInfo();
		
		if(splitSelectStmt.length == 1){
			columnInfo.setColumnName(trimmedValue);
			
		}else if(splitSelectStmt.length == 2){ // TABLE��.COLUMN�� ����
			columnInfo.setTableName(splitSelectStmt[0].trim());
			columnInfo.setColumnName(splitSelectStmt[1].trim());
			
		}else{
			throw new Exception("SELECT STATEMENT ERROR");
		}
		
		return columnInfo;
	}
}
