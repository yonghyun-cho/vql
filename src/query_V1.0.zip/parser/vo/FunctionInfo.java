package query.parser.vo;

import java.util.ArrayList;
import java.util.List;

public class FunctionInfo implements PrimitiveType {
	private String functionName = "";
	private List<PrimitiveType> valueList = new ArrayList<PrimitiveType>();
	
	public String getFunctionName() {
		return functionName;
	}
	public void setFunctionName(String functionName) {
		this.functionName = functionName;
	}
	public List<PrimitiveType> getValueList() {
		return valueList;
	}
	public void setValueList(List<PrimitiveType> valueList) {
		this.valueList = valueList;
	}
}
